from __future__ import unicode_literals

from django.apps import AppConfig


class RandomWord3AppConfig(AppConfig):
    name = 'random_word3_app'
